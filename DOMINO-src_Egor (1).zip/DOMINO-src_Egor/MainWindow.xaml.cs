﻿using DOMINO.Modules;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace DOMINO
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window 
    {
        //Все доминошки
        public List<Tile> allTilles;
        //Данный ход игрока
        public int PlayerMove;
        public Player player1;
        public Player player2;
        //Подключение игрового движка 
        GameEngine engine = new GameEngine();
        public MainWindow()
        {
            InitializeComponent();
            this.WindowState = WindowState.Maximized;
            this.WindowStyle = WindowStyle.None;
            this.ResizeMode = ResizeMode.NoResize;
            GameBoard.MouseDown += CanvasClicked;
        }
        //Кнопка создания новой игры
        void NewGameButton_Click(object sender, RoutedEventArgs e)
        {
            player1 = new Player();
            player2 = new Player();
            //Связь данных о игроке с дижком
            ref Player playerNOW = ref engine.PlayerNOW;
            playerNOW = player1;

            if (allTilles != null) allTilles.Clear();
            allTilles = new List<Tile>();
                for (int i = 0; i <= 6; ++i)
                {
                    for (int j = 0; j <= 6; ++j)
                    {
                        Tile tile = new Tile();
                        tile.value1 = i; tile.value2 = j; tile.isHorizontal = 0;
                        allTilles.Add(tile);
                    }
                }
            Shuffle<Tile>(allTilles);
            //Раздача костяшек игрокам
            engine.GiveHandPlayer(ref player1, ref allTilles);
            engine.GiveHandPlayer(ref player2, ref allTilles);
            //Отрисовка костяшек игрока 1
            engine.DrawHandTile(ref player1, ref HandPlayer);
        }
        //Метод перемешивает элементы в List
        public static void Shuffle<T>(IList<T> list)
        {
            Random rng = new Random();
            int n = list.Count();
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                (list[k], list[n]) = (list[n], list[k]); // Обмен значениями
            }
        }
        //На будущее
        public void DrawButton_Click(object sender, RoutedEventArgs e)
        {

        }
        //На будущее
        public void PassButton_Click(object sender, RoutedEventArgs e)
        {

        }
        //Кнопка выхода из проги
        public void ExiteButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        public void CanvasClicked(object sender, MouseButtonEventArgs e)
        {
            engine.CanvasClicked(sender, e, this);
        }
        public void UpdateTilePosition(Tile tile, Canvas canvas)
        {
            var existingNumbers = canvas.Children.OfType<TextBlock>().Where(tb => tb.Tag == tile).ToList();
            foreach (var number in existingNumbers)
            {
                canvas.Children.Remove(number);
            }

            TextBlock number1 = new TextBlock
            {
                Text = tile.value1.ToString(),
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Tag = tile 
            };

            TextBlock number2 = new TextBlock
            {
                Text = tile.value2.ToString(),
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Tag = tile 
            };

            if (tile.isHorizontal == 1)
            {
                Canvas.SetLeft(number1, Canvas.GetLeft(tile.rectangle) + 5);
                Canvas.SetTop(number1, Canvas.GetTop(tile.rectangle) + tile.height / 4);

                Canvas.SetLeft(number2, Canvas.GetLeft(tile.rectangle) + tile.width - 20);
                Canvas.SetTop(number2, Canvas.GetTop(tile.rectangle) + tile.height / 4);
            }
            else
            {
                Canvas.SetLeft(number1, Canvas.GetLeft(tile.rectangle) + tile.width / 4);
                Canvas.SetTop(number1, Canvas.GetTop(tile.rectangle) + 5);

                Canvas.SetLeft(number2, Canvas.GetLeft(tile.rectangle) + tile.width / 4);
                Canvas.SetTop(number2, Canvas.GetTop(tile.rectangle) + tile.height - 20);
            }

            canvas.Children.Add(number1);
            canvas.Children.Add(number2);
        }
    }
    //Класс кости
    public class Tile
    {
        public int value1;
        public int value2;
        public int width = 30;
        public int height = 60;
        public Rectangle rectangle = new Rectangle();
        public int isHorizontal;
        // часть, которая не соприкасается с другой костью, если нет, то -1
        public int end_tile;
    }

    //Класс игрока
    public class Player
    {
        public string name;
        public List<Tile> hand = new List<Tile>();        
    }
}