﻿using DOMINO;
using DOMINO.Modules;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DOMINO.Modules
{
    public class GameEngine
    {
        //ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ!!!
        public Player PlayerNOW = new Player();
        public bool Clicked_rectangle = false;
        MainWindow mainwindow;
        //!!!

        public void mainw(MainWindow mainWindow) { mainwindow = mainWindow; }
        //Метод отвечает за раздачу костей игроку
        public void GiveHandPlayer(ref Player player, ref List<Tile> list)
        {
            while (player.hand.Count != 7 && list.Count() !=0)
            {
                player.hand.Add(list[0]);
                list.RemoveAt(0);
            }
        }
        //Метод отрисовывает костяшки руки игрока
        public void DrawHandTile(ref Player player, ref StackPanel spanel)
        {
            foreach (var tile in player.hand)
            {
                var visual = CreateDominoTileVisual(tile);
                spanel.Children.Add(visual);
            }       
        }
        //Метод отвечает за проверку, где находится кость
        public void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Canvas tile =(Canvas) sender;
            // Проверка, где находится кость
            if (tile.Parent is StackPanel)
            {
                Tile_clickedHand(tile);
            }
            else if (tile.Parent is Canvas)
            {
                TileClickedCanvas(tile);
            }
        }

        //Выбор кости в руке после клика на него
        public void Tile_clickedHand(Canvas tile)
        {
            if (Clicked_rectangle)
            {
                foreach (var child in tile.Children) {
                    if (child is Rectangle rectangle) {
                        //В случае повторения кости снимает её
                        if (rectangle.Stroke == Brushes.Yellow)
                        {
                            Clicked_rectangle = false;
                            rectangle.Stroke = Brushes.Black;
                            return;
                        }
                    }
                }
            }
            else
            //Очищает обводки другим и делает себе
            {
                for (int i = 0; i < PlayerNOW.hand.Count(); ++i)
                {
                    foreach (var child in PlayerNOW.hand[i].rectangle.Children)
                    {
                        if (child is Rectangle rectangle)
                        {
                            rectangle.Stroke = Brushes.Black;
                        }
                    }
                }
                foreach (var child in tile.Children)
                    if (child is Rectangle rectangle)
                    {
                        rectangle.Stroke = Brushes.Yellow;
                    }
                Clicked_rectangle = true;
            }
        }
        //Метод отвечающий за нажатие левой кнопкой мыши по канвасу
        public void CanvasLeftClicked(object sender, MouseButtonEventArgs e, MainWindow mainWindow)
        {
            //Поиск нажатой кости и добавления на канвас
            for (int i=0;i<PlayerNOW.hand.Count(); ++i)
            {
                foreach (var child in PlayerNOW.hand[i].rectangle.Children)
                {
                    if (child is Rectangle rectangle)
                    {
                        if (rectangle.Stroke == Brushes.Yellow)
                        {
                            //Проверка на наличие в канвасе доминошек
                            if (mainWindow.GameBoard.Children.Count == 0)
                            {
                                //При отсутствии первая кость ставится в центр
                                mainWindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                mainWindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                rectangle.Stroke = Brushes.Black;
                                Point centerCanvas = new Point(mainWindow.GameBoard.ActualWidth / 2, mainWindow.GameBoard.ActualHeight / 2);
                                Canvas.SetLeft(PlayerNOW.hand[i].rectangle, centerCanvas.X);
                                Canvas.SetTop(PlayerNOW.hand[i].rectangle, centerCanvas.Y);
                                mainWindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                Clicked_rectangle = false;
                                break;
                            }
                        }
                    }
                }
            }
        }

        //Метод отвечающий за нажатие правой кнопки мыши по канвасу
        public void CanvasRightClicked(object sender, MouseButtonEventArgs e, MainWindow mainWindow)
        {
            for (int i = 0; i < PlayerNOW.hand.Count(); i++)
            {
                foreach (var child in PlayerNOW.hand[i].rectangle.Children)
                {
                    if (child is Rectangle rectangle)
                    {
                        if (rectangle.Stroke == Brushes.Yellow)
                        {
                            //Изменение направления кости, поворот на 90 градусов по часовой
                            PlayerNOW.hand[i].direction = PlayerNOW.hand[i].direction == 4 ? 1 : PlayerNOW.hand[i].direction + 1;
                            double angle = 0;
                            switch (PlayerNOW.hand[i].direction)
                            {
                                case 2: angle = 90; break;
                                case 3: angle = 180; break;
                                case 4: angle = 270; break;
                                default: angle = 0; break;
                            }
                            PlayerNOW.hand[i].rectangle.RenderTransform = new RotateTransform(angle, PlayerNOW.hand[i].width / 2, PlayerNOW.hand[i].height / 2);
                            break;
                        }
                    }
                }
            }
        }
        void MadeDirection(Tile tile)
        {
            //Изменение направления кости, поворот на 90 градусов по часовой
            tile.direction = tile.direction == 4 ? 1 : tile.direction + 1;
            double angle = 0;
            switch (tile.direction)
            {
                case 2: angle = 90; break;
                case 3: angle = 180; break;
                case 4: angle = 270; break;
                default: angle = 0; break;
            }
            tile.rectangle.RenderTransform = new RotateTransform(angle, tile.width / 2, tile.height / 2);
        }

        //Метод, отвечающий за нажатие костяшки на канвасе, для того, чтобы походить
        void TileClickedCanvas(Canvas tile)
        {
            for (int i = 0; i < PlayerNOW.hand.Count(); i++)
            {
                foreach (var child in PlayerNOW.hand[i].rectangle.Children)
                {
                    if (child is Rectangle rectangle && rectangle.Stroke == Brushes.Yellow)
                    {
                        if (mainwindow.GameBoard.Children.Count == 1)
                        {
                            //Первое значение костяшки на канвасе и в руке совпадают
                            if (mainwindow.TilesOnCanvas[0].value1 == PlayerNOW.hand[i].value1)
                            {
                                //Пока сторона в которую кости смотрят не совпадут
                                double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[0].rectangle);
                                double top = Canvas.GetTop(mainwindow.TilesOnCanvas[0].rectangle);
                                bool done_flag = true;
                                //выбор в зависимости от направления
                                switch (mainwindow.TilesOnCanvas[0].direction)
                                {
                                    case 1:
                                        if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 2:
                                        if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 3:
                                        if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 4:
                                        if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - (PlayerNOW.hand[i].height/2 + PlayerNOW.hand[i].width/2));
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                }
                                if (done_flag)
                                {
                                    if (mainwindow.TilesOnCanvas[0].value1 == mainwindow.TilesOnCanvas[0].value2)
                                        mainwindow.TilesOnCanvas[0].value1 = -1;
                                    //Записывает конечную костяшку
                                    mainwindow.TilesOnCanvas[0].end_tile = mainwindow.TilesOnCanvas[0].value2;
                                    PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value2;
                                    mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                }
                            }
                            //Первое значение костяшки на канвасе и в вторая в руке совпадают
                            else if (mainwindow.TilesOnCanvas[0].value1 == PlayerNOW.hand[i].value2)
                            {
                                double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[0].rectangle);
                                double top = Canvas.GetTop(mainwindow.TilesOnCanvas[0].rectangle);
                                bool done_flag = true;
                                switch (mainwindow.TilesOnCanvas[0].direction)
                                {
                                    case 1:
                                        if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 2:
                                        if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 3:
                                        if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 4:
                                        if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - (PlayerNOW.hand[i].height / 2 + PlayerNOW.hand[i].width / 2));
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                }
                                if (done_flag)
                                {
                                    if (mainwindow.TilesOnCanvas[0].value1 == mainwindow.TilesOnCanvas[0].value2)
                                        mainwindow.TilesOnCanvas[0].value1 = -1;
                                    //Записывает конечную костяшку
                                    mainwindow.TilesOnCanvas[0].end_tile = mainwindow.TilesOnCanvas[0].value2;
                                    PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value1;
                                    mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                }
                            }
                            //Второе значение костяшки на канвасе и в руке совпадают
                            else if (mainwindow.TilesOnCanvas[0].value2 == PlayerNOW.hand[i].value2)
                            {
                                double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[0].rectangle);
                                double top = Canvas.GetTop(mainwindow.TilesOnCanvas[0].rectangle);
                                bool done_flag = true;
                                switch (mainwindow.TilesOnCanvas[0].direction)
                                {
                                    case 1:
                                        if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width/2);
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 2:
                                        if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width/2);
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 3:
                                        if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width / 2);
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 4:
                                        if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width/2);
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                }
                                if (done_flag)
                                {
                                    if (mainwindow.TilesOnCanvas[0].value1 == mainwindow.TilesOnCanvas[0].value2)
                                        mainwindow.TilesOnCanvas[0].value2 = -1;
                                    //Записывает конечную костяшку
                                    mainwindow.TilesOnCanvas[0].end_tile = mainwindow.TilesOnCanvas[0].value1;
                                    PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value1;
                                    mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                }
                            }
                            // Второе значение костяшки на канвасе и первая в руке совпадают
                            else if (mainwindow.TilesOnCanvas[0].value2 == PlayerNOW.hand[i].value1)
                            {
                                double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[0].rectangle);
                                double top = Canvas.GetTop(mainwindow.TilesOnCanvas[0].rectangle);
                                bool done_flag = true;
                                switch (mainwindow.TilesOnCanvas[0].direction)
                                {
                                    case 1:
                                        if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2);
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 2:
                                        if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width / 2);
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 3:
                                        if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width / 2);
                                        else
                                            Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                    case 4:
                                        if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                        if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2);
                                        else
                                            Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                        //Убираем обводку
                                        foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                        {
                                            if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                        }
                                        Clicked_rectangle = false;
                                        mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                        mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                        break;
                                }
                                if (done_flag)
                                {
                                    if (mainwindow.TilesOnCanvas[0].value1 == mainwindow.TilesOnCanvas[0].value2)
                                        mainwindow.TilesOnCanvas[0].value2 = -1;
                                    //Записывает конечную костяшку
                                    mainwindow.TilesOnCanvas[0].end_tile = mainwindow.TilesOnCanvas[0].value1;
                                    PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value2;
                                    mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                }
                            }
                        }
                        else
                        //Если костяшек на поле больше чем 2
                        {
                            for (int j=0; j < mainwindow.TilesOnCanvas.Count(); ++j)
                            {
                                if (mainwindow.TilesOnCanvas[j].rectangle == tile)
                                {
                                    //первое значение в руке и на поле сопадают
                                    if (PlayerNOW.hand[i].value1 == mainwindow.TilesOnCanvas[j].end_tile)
                                    {
                                        //Первая в руке и на канвасе совпадают
                                        if (mainwindow.TilesOnCanvas[j].end_tile == mainwindow.TilesOnCanvas[j].value1)
                                        {
                                            //Пока сторона в которую кости смотрят не совпадут
                                            double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[j].rectangle);
                                            double top = Canvas.GetTop(mainwindow.TilesOnCanvas[j].rectangle);
                                            bool done_flag = true;
                                            //выбор в зависимости от направления
                                            switch (mainwindow.TilesOnCanvas[j].direction)
                                            {
                                                case 1:
                                                    if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 2:
                                                    if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 3:
                                                    if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 4:
                                                    if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - (PlayerNOW.hand[i].height / 2 + PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                            }
                                            if (done_flag)
                                            {
                                                //Записывает конечную костяшку
                                                mainwindow.TilesOnCanvas[j].end_tile = -1;
                                                PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value2;
                                                mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                            }
                                        }
                                        //Второе значение костяшки на канвасе и первая в руке совпадают
                                        else if (mainwindow.TilesOnCanvas[j].end_tile == mainwindow.TilesOnCanvas[j].value2)
                                        {
                                            double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[j].rectangle);
                                            double top = Canvas.GetTop(mainwindow.TilesOnCanvas[j].rectangle);
                                            bool done_flag = true;
                                            switch (mainwindow.TilesOnCanvas[j].direction)
                                            {
                                                case 1:
                                                    if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 2:
                                                    if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 3:
                                                    if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 4:
                                                    if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                            }
                                            if (done_flag)
                                            {
                                                mainwindow.TilesOnCanvas[j].end_tile = -3;
                                                PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value2;
                                                                            mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                            }
                                        }
                                    }
                                    // Если значение 2 на костяшке равняется концу
                                    else if (PlayerNOW.hand[i].value2 == mainwindow.TilesOnCanvas[j].end_tile)
                                    {
                                        //Если значение 2 на костяшке равняется значению 2 на поле
                                        if (mainwindow.TilesOnCanvas[j].end_tile == mainwindow.TilesOnCanvas[j].value2)
                                        {
                                            double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[j].rectangle);
                                            double top = Canvas.GetTop(mainwindow.TilesOnCanvas[j].rectangle);
                                            bool done_flag = true;
                                            switch (mainwindow.TilesOnCanvas[j].direction)
                                            {
                                                case 1:
                                                    if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 2:
                                                    if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 3:
                                                    if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height + PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 4:
                                                    if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2);
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                            }
                                            if (done_flag)
                                            {
                                                //Записывает конечную костяшку
                                                mainwindow.TilesOnCanvas[j].end_tile = -1;
                                                PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value1;
                                                mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                            }
                                        }
                                        //Если значение 2 в руке совпадает со значением 1 на поле
                                        else if (mainwindow.TilesOnCanvas[j].end_tile == mainwindow.TilesOnCanvas[j].value1)
                                        {
                                            double left = Canvas.GetLeft(mainwindow.TilesOnCanvas[j].rectangle);
                                            double top = Canvas.GetTop(mainwindow.TilesOnCanvas[j].rectangle);
                                            bool done_flag = true;
                                            switch (mainwindow.TilesOnCanvas[j].direction)
                                            {
                                                case 1:
                                                    if (PlayerNOW.hand[i].direction == 3) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top - PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 2:
                                                    if (PlayerNOW.hand[i].direction == 4) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left + PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 3:
                                                    if (PlayerNOW.hand[i].direction == 1) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 2 || PlayerNOW.hand[i].direction == 4)
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + (PlayerNOW.hand[i].height - PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetTop(PlayerNOW.hand[i].rectangle, top + PlayerNOW.hand[i].height);
                                                    Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                                case 4:
                                                    if (PlayerNOW.hand[i].direction == 2) { done_flag = false; break; }
                                                    if (PlayerNOW.hand[i].direction == 1 || PlayerNOW.hand[i].direction == 3)
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - (PlayerNOW.hand[i].height / 2 + PlayerNOW.hand[i].width / 2));
                                                    else
                                                        Canvas.SetLeft(PlayerNOW.hand[i].rectangle, left - PlayerNOW.hand[i].height);
                                                    Canvas.SetTop(PlayerNOW.hand[i].rectangle, top);
                                                    //Убираем обводку
                                                    foreach (var child2 in PlayerNOW.hand[i].rectangle.Children)
                                                    {
                                                        if (child is Rectangle rectangle2) rectangle2.Stroke = Brushes.Black;
                                                    }
                                                    Clicked_rectangle = false;
                                                    mainwindow.HandPlayer.Children.Remove(PlayerNOW.hand[i].rectangle);
                                                    mainwindow.GameBoard.Children.Add(PlayerNOW.hand[i].rectangle);
                                                    break;
                                            }
                                                if (done_flag)
                                            {
                                                //Записывает конечную костяшку
                                                mainwindow.TilesOnCanvas[j].end_tile = -1;
                                                PlayerNOW.hand[i].end_tile = PlayerNOW.hand[i].value1;
                                                mainwindow.TilesOnCanvas.Add(PlayerNOW.hand[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //Метод отвечающий за работу правил игры
        public void GameStart(MainWindow mainWindow)
        {
            mainWindow.CurrentPlayerText.Text = PlayerNOW.name;
        }
        public Canvas CreateDominoTileVisual(Tile tile)
        {
            var tileCanvas = new Canvas
            {
                Width = tile.width,
                Height = tile.height
            };
            tileCanvas.MouseDown += Rectangle_MouseDown;

            var rect = new Rectangle
            {
                Width = tile.width,
                Height = tile.height,
                Stroke = Brushes.Black,
                Fill = Brushes.White,
                RadiusX = 4,
                RadiusY = 4
            };
            tileCanvas.Children.Add(rect);

            // Разделительная линия
            var line = new Line
            {
                Stroke = Brushes.Black,
                StrokeThickness = 2,
                X1 = 0,
                Y1 = tile.height / 2,
                X2 = tile.width,
                Y2 = tile.height / 2
            };
            tileCanvas.Children.Add(line);

            // Число 1
            var tb1 = new TextBlock
            {
                Text = tile.value1.ToString(),
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black
            };
            // Число 2
            var tb2 = new TextBlock
            {
                Text = tile.value2.ToString(),
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black
            };

            if (tile.direction != 1)
            {
                Canvas.SetLeft(tb1, tile.width * 0.15);
                Canvas.SetTop(tb1, tile.height * 0.25);
                Canvas.SetLeft(tb2, tile.width * 0.65);
                Canvas.SetTop(tb2, tile.height * 0.25);
            }
            else
            {
                Canvas.SetLeft(tb1, tile.width * 0.25);
                Canvas.SetTop(tb1, tile.height * 0.15);
                Canvas.SetLeft(tb2, tile.width * 0.25);
                Canvas.SetTop(tb2, tile.height * 0.65);
            }

            tileCanvas.Children.Add(tb1);
            tileCanvas.Children.Add(tb2);

            // Поворот контейнера в зависимости от направления
            // 1 - вверх (0°), 2 - вправо (90°), 3 - вниз (180°), 4 - влево (270°)
            double angle = 0;
            switch (tile.direction)
            {
                case 2: angle = 90; break;
                case 3: angle = 180; break;
                case 4: angle = 270; break;
                default: angle = 0; break;
            }
            tileCanvas.RenderTransform = new RotateTransform(angle, tile.width / 2, tile.height / 2);
            tile.rectangle = tileCanvas;
            return tileCanvas;
        }
    }
}
